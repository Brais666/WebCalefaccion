Hola {{ $demo->receiver }},
Esta es una demo en HTML! Soy Brais, no respondas.
 
Valores del objeto "demo":
 
Nombre: {{ $demo->demo_two }}

 
 
Un saludo ;)

{{ $demo->sender }}