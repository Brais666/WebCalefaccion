<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<div class="">
  <h2>Bienvenido {{ $demo->demo_two }}!</h2>

  <p>Esperemos que nuestra aplicación te sea de gran utilidad!</p>

  <!--<h4>Codigo de descuento</h4>-->

  Un saludo ;)
<br/>

{{ $demo->sender }}


  Enviado automáticamente desde <a href="www.Simongrup.com" title="VenexCargo Utah">SimonGrup S.L.</a>

</div>