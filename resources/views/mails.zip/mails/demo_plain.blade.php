Hola {{ $demo->receiver }},
Esta es una demo en HTML! Soy Brais, no respondas.
 
Valores del objeto "demo":
 
Id: {{ $demo->demo_one }}
Demo Two: {{ $demo->demo_two }}
Demo One: {{ $demo->demo_three }}
Demo Two: {{ $demo->demo_four }}
Demo One: {{ $demo->demo_five }}
Demo Two: {{ $demo->demo_six }}
Demo One: {{ $demo->demo_seven }}
Demo Two: {{ $demo->demo_eight }}
Demo One: {{ $demo->demo_nine }}
Demo Two: {{ $demo->demo_ten }}
Demo One: {{ $demo->demo_eleven }}
Demo Two: {{ $demo->demo_twelve }}
 
 
Un saludo ;)

{{ $demo->sender }}