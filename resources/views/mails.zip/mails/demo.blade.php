<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<div class="container">  
             
           Hola {{ $demo->receiver }},

<p>Es una demo del mail api de Laravel.Soy Brais, no respondas, sólo es una prueba en HTML.</p>
 njknbjk
 <hr></hr>
<p><u>Pedido realizado:</u></p>
           <section class="separacion"></section>
           <section class="separacion"></section>
           <section class="separacion"></section>
           <section class="gris">
           
             <table class="table table-bordered table-striped table-hover clientes">
                <tr>
                    <!--<th>ID</th>-->
                    <th>Nombre</th>
                    <th>DNI</th>
                    <th>Dir.</th>
                    <th>Localidad</th>
                    <th>Provincia</th>
                    <th>C. Postal</th>
                    <th>Canal:</th>
                    <th>Estado</th>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Total</th>
                </tr> 
                <tr>
                    <!--<td>{{ $demo->demo_one }}</td>-->
                    <td>{{ $demo->demo_two }}</td>
                    <td>{{ $demo->demo_three }}</td>
                    <td>{{ $demo->demo_four }}</td>
                    <td>{{ $demo->demo_five }}</td>
                    <td>{{ $demo->demo_six }}</td>
                    <td>{{ $demo->demo_seven }}</td>
                    <td>{{ $demo->demo_eight }}</td>
                    @if($demo->demo_nine  == 'Pendiente')
                            <td class="text-warning">{{ $demo->demo_nine }}</td>
                    @elseif($pedidos->estado == 'Confirmado')
                            <td class="text-success">{{ $demo->demo_nine }}</td>
                    @endif
                    
                    <td>{{ $demo->demo_ten }}</td>
                    <td>{{ $demo->demo_eleven }} l</td>
                    <td>{{ $demo->demo_twelve }} eur.</td>
                </tr> 
           </table>
            
        Un saludo ;)
        <br/>

{{ $demo->sender }}
</div>

 

 

 

